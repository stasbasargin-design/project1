@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js не найден. Установите Node.js 20 LTS или новее.
  pause
  exit /b 1
)
if not exist "%~dp0ADMIN_KEY.txt" (
  echo Не найден ADMIN_KEY.txt. Распакуйте полный комплект.
  pause
  exit /b 1
)
set /p "ITUS_SETTINGS_KEY="<"%~dp0ADMIN_KEY.txt"
if "%PORT%"=="" set PORT=8080
echo Запуск ИТУС на http://localhost:%PORT%/p/max-service/
node server.mjs
pause
