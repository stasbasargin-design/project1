#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
: "${PORT:=8080}"
export PORT
ITUS_SETTINGS_KEY="$(cat ADMIN_KEY.txt)"
export ITUS_SETTINGS_KEY
exec node server.mjs
