$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw "Node.js не найден. Установите Node.js 20 LTS или новее."
}
$env:ITUS_SETTINGS_KEY = (Get-Content (Join-Path $PSScriptRoot "ADMIN_KEY.txt") -Raw).Trim()
if (-not $env:PORT) { $env:PORT = "8080" }
Write-Host "Запуск ИТУС на http://localhost:$env:PORT/p/max-service/"
node server.mjs
