import { mkdirSync, readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { timingSafeEqual } from 'node:crypto';
export function createSettingsStore({initialTarget, basePath}) {
 const dir=resolve(process.env.ITUS_STATE_DIR || './data');mkdirSync(dir,{recursive:true,mode:0o700});
 const file=join(dir,'connection.json'), keyFile=new URL('./ADMIN_KEY.txt',import.meta.url);
 let key=process.env.ITUS_SETTINGS_KEY;
 if(!key){key=readFileSync(keyFile,'utf8').trim();if(!key)throw Error('ADMIN_KEY.txt пуст. Заполните ключ администратора.');console.log('Ключ настроек находится в файле ADMIN_KEY.txt рядом с START_WINDOWS.bat');}
 const allowed=new Set([new URL(initialTarget).origin,...(process.env.ITUS_ALLOWED_API_ORIGINS||'').split(',').map(x=>x.trim()).filter(Boolean)]);
 function validate(value){
  const apiPath=String(value.apiPath||'').trim().replace(/\/+$/,'');
  const prefix=basePath==='/'?'':basePath;
  if(!apiPath.startsWith(prefix+'/')||!/^\/[a-zA-Z0-9_/-]+$/.test(apiPath)||apiPath.includes('//'))throw Error('Маршрут API должен находиться внутри '+(prefix||'/')+' и содержать только латинские буквы, цифры, /, _ и -.');
  const local=apiPath.slice(prefix.length);
  if(local==='/'||/^\/(?:_itus|assets|config|health)(?:\/|$)/.test(local))throw Error('Этот маршрут зарезервирован приложением.');
  const target=new URL(String(value.target||'').trim());
  if(!['https:','http:'].includes(target.protocol)||target.username||target.password||target.search||target.hash)throw Error('Укажите полный HTTP(S)-адрес сервиса без пароля, параметров и #.');
  if(!allowed.has(target.origin))throw Error('Этот сервер не разрешён. Администратор должен добавить его origin в ITUS_ALLOWED_API_ORIGINS.');
  return {apiPath,target:target.href.replace(/\/+$/,'')};
 }
 let value=existsSync(file)?validate(JSON.parse(readFileSync(file,'utf8'))):validate({apiPath:(basePath==='/'?'':basePath)+'/api/1c',target:initialTarget});
 return {get:()=>({...value}), localPath:()=>value.apiPath.slice(basePath==='/'?0:basePath.length),authorized(input){const a=Buffer.from(String(input||'')),b=Buffer.from(key);return a.length===b.length&&timingSafeEqual(a,b);},save(input){const next=validate(input);writeFileSync(file+'.tmp',JSON.stringify(next,null,2),{mode:0o600});renameSync(file+'.tmp',file);value=next;return {...value};}};
}
