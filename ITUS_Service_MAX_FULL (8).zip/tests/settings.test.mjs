import assert from 'node:assert/strict';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const dir=mkdtempSync(join(tmpdir(),'itus-settings-'));
const upstream=http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify({path:req.url}));});upstream.listen(0,'127.0.0.1');await once(upstream,'listening');
const origin=`http://127.0.0.1:${upstream.address().port}`;let child,log='';
async function start(){child=spawn(process.execPath,[new URL('../server.mjs',import.meta.url).pathname],{env:{...process.env,PORT:'18083',ITUS_STATE_DIR:dir,ITUS_SETTINGS_KEY:'test-key',ONE_C_TARGET:origin+'/old'},stdio:['ignore','pipe','pipe']});child.stdout.on('data',c=>log+=c);await new Promise((resolve,reject)=>{child.stdout.on('data',c=>{if(String(c).includes('ИТУС запущен'))resolve();});child.once('exit',()=>reject(Error('Server exited')));});}
const url='http://127.0.0.1:18083/p/max-service';
async function save(value,key='test-key'){return fetch(url+'/_itus/settings',{method:'POST',headers:{'Content-Type':'application/json','X-ITUS-Settings-Key':key},body:JSON.stringify(value)});}
try{
 await start();const desired={apiPath:'/p/max-service/api/new',target:origin+'/new/hs/max-service'};
 assert.equal((await save(desired,'bad-key')).status,403);
 assert.equal((await save({...desired,target:'https://untrusted.invalid/api'})).status,400);
 assert.equal((await save({...desired,apiPath:'/outside'})).status,400);
 assert.equal((await save(desired)).status,200);
 let response=await fetch(url+'/api/new/ping',{method:'POST',body:'{}'});assert.equal(response.headers.get('x-itus-upstream'),origin+'/new/hs/max-service/ping');assert.equal((await response.json()).path,'/new/hs/max-service/ping');
 assert.ok(log.includes('1c.settings.updated'));assert.ok(log.includes('/new/hs/max-service/ping'));assert.ok(!log.includes('test-key'));
 child.kill();await once(child,'exit');await start();
 assert.deepEqual((await(await fetch(url+'/_itus/settings')).json()).settings,desired);
 response=await fetch(url+'/api/new/ping',{method:'POST',body:'{}'});assert.equal((await response.json()).path,'/new/hs/max-service/ping');
 console.log('Settings: OK — authentication, validation, live routes, actual upstream logs, persistence after restart.');
}finally{if(child){child.kill();}upstream.close();rmSync(dir,{recursive:true,force:true});}
