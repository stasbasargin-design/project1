import assert from 'node:assert/strict';
import http from 'node:http';
import {fork} from 'node:child_process';
import {once} from 'node:events';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const dir=mkdtempSync(join(tmpdir(),'itus-launcher-'));
const old=http.createServer((req,res)=>res.end('<!doctype html>Old version'));
old.listen(0,'127.0.0.1');await once(old,'listening');
const upstream=http.createServer((req,res)=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify({success:true,path:req.url}));});upstream.listen(0,'127.0.0.1');await once(upstream,'listening');
const target=`http://127.0.0.1:${upstream.address().port}/original`;
const child=fork(new URL('../scripts/launch.mjs',import.meta.url),[],{env:{...process.env,ITUS_NO_OPEN:'1',ITUS_STATE_DIR:dir,ONE_C_TARGET:target,PORT:String(old.address().port)},stdio:['ignore','pipe','pipe','ipc']});
let output='';child.stdout.on('data',c=>output+=c);child.stderr.on('data',c=>output+=c);
try{
 const ready=await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(Error('Startup timed out')),15000);child.on('message',m=>{if(m.event==='launcher-ready'){clearTimeout(timeout);resolve(m);}});child.once('exit',()=>{clearTimeout(timeout);reject(Error(output));});});
 assert.notEqual(new URL(ready.url).port,String(old.address().port));
 const configURL=new URL('_itus/settings',ready.url);const result=await(await fetch(configURL)).json();assert.equal(result.version,'2.1.6');assert.equal(result.settings.target,target);
 const key=readFileSync(new URL('../ADMIN_KEY.txt',import.meta.url),'utf8').trim();
 const saved=await fetch(configURL,{method:'POST',headers:{'Content-Type':'application/json','X-ITUS-Settings-Key':key},body:JSON.stringify({apiPath:'/api/1c',target:target+'/changed'})});assert.equal(saved.status,200);
 const data=await saved.json();assert.equal(data.settings.apiPath,'/api/1c');
 const response=await fetch(new URL(data.settings.apiPath+'/ping',ready.url),{method:'POST',body:'{}'});assert.equal((await response.json()).path,'/original/changed/ping');
 assert.match(await(await fetch(ready.url)).text(),/assets\/app.js/);
 assert.equal(await(await fetch(`http://127.0.0.1:${old.address().port}`)).text(),'<!doctype html>Old version');
 console.log('Launcher: OK — occupied port, correct server identity, bundled key, legacy /api/1c, real settings save and rerouted request; old process intact.');
}finally{child.kill();await once(child,'exit');old.close();upstream.close();rmSync(dir,{recursive:true,force:true});}
