import { fork, execFile } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
const root=fileURLToPath(new URL('../',import.meta.url));
const key=readFileSync(new URL('../ADMIN_KEY.txt',import.meta.url),'utf8').trim();
if(!key)throw new Error('Файл ADMIN_KEY.txt пуст');
const nonce=randomUUID();
const child=fork(new URL('../server.mjs',import.meta.url),[],{cwd:root,env:{...process.env,ITUS_SETTINGS_KEY:key,ITUS_LAUNCH_NONCE:nonce,ITUS_LOCAL_LAUNCH:'1',PORT:process.env.PORT||'8080'},stdio:['inherit','inherit','inherit','ipc']});
const timer=setTimeout(()=>{console.error('Сервер не подтвердил готовность за 15 секунд.');child.kill();process.exitCode=1;},15000);
child.on('message',async message=>{
 if(message?.event!=='ready'||message.nonce!==nonce)return;
 clearTimeout(timer);
 try{
  const url=`http://127.0.0.1:${message.port}${message.basePath==='/'?'':message.basePath}/`;
  const response=await fetch(new URL('_itus/settings',url),{signal:AbortSignal.timeout(5000)});
  const result=await response.json();
  if(!response.ok||result.version!=='2.1.6'||!result.settings?.target)throw Error('Не подтверждён сервер настроек новой версии');
  console.log(`\nГОТОВО. Откройте приложение: ${url}\nКлюч находится в ADMIN_KEY.txt.\nНе закрывайте это окно во время работы.\n`);
  process.send?.({event:'launcher-ready',url,settings:result.settings});
  if(process.env.ITUS_NO_OPEN!=='1'){
   const command=process.platform==='win32'?'cmd':process.platform==='darwin'?'open':'xdg-open';
   const args=process.platform==='win32'?['/c','start','',url]:[url];
   execFile(command,args,error=>{if(error)console.log('Откройте адрес выше вручную.');});
  }
 }catch(error){console.error('Ошибка проверки запуска:',error.message);child.kill();process.exitCode=1;}
});
child.on('exit',code=>{clearTimeout(timer);process.exitCode=code||process.exitCode||0;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>child.kill());
