import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
for(const test of ['static-path','api-normalizers','source-contract','acceptance-regression','settings','subpath','launcher']){
 const result=spawnSync(process.execPath,[`tests/${test}.test.mjs`],{cwd:root,encoding:'utf8'});
 if(result.status!==0){console.error(result.stdout,result.stderr);process.exit(result.status||1);}
 console.log(result.stdout.trim().split('\n').at(-1));
}
